package com.example.clicker;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class login extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        TextView username = (TextView) findViewById(R.id.editTextTextPersonName);
        TextView roomcode = (TextView) findViewById(R.id.editTextNumberPassword);

        Button loginbtn = (Button) findViewById(R.id.btnNext);

        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (roomcode.getText().toString().equals("20000")) {
                    Toast.makeText(login.this, "Proceed", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(login.this, "Invalid Room Code", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}